#!/system/bin/sh
#export LD_LIBRARY_PATH=/data/data/per.pqy.apktool/lix
/data/data/per.pqy.apktool/lix/jvm/java-7-openjdk-armhf/jre/bin/java -Xmx1024m -jar /data/data/per.pqy.apktool/mydata/smali-2.0.2.jar  "$@" && echo "OK!"
