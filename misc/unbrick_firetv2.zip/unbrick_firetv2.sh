#!/bin/bash

cd $(dirname $0)

[[ $(uname -s) = "Darwin" ]] && INJECT=mediatek_inject.osx || INJECT=mediatek_inject.linux

echo "Which image filename do you want to use? <unbrick.img|unbrick+ramdisk.img> "
read img

if [ ! -f $img ]; then
	echo "The image filename was missing.  Did you type it correctly?"
	exit -1
fi

./handshake.py

echo "Flashing unbrick image $img..."
./$INJECT firetv2 $(cat comport.txt) $img /system -
