﻿
namespace VirtualRouter.Wlan.WinAPI
{
    //http://msdn.microsoft.com/en-us/library/dd439503%28VS.85%29.aspx
    public enum WLAN_HOSTED_NETWORK_PEER_AUTH_STATE
    {
        wlan_hosted_network_peer_state_invalid,
        wlan_hosted_network_peer_state_authenticated
    }
}
