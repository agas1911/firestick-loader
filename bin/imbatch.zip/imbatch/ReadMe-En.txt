ImBatch V5.2.0
=======================================================================

How to install:
-----------------------------------------------------------------------

From the installer:
	Just follow the install wizard.
	
From the zip:
	Just unzip all the files into a directory you want then launch it.


What is ImBatch?
-----------------------------------------------------------------------

ImBatch is the image batch processor for Windows. ImBatch features an excellent user interface that's easy to use and understand. It handles all popular image formats. What makes the tool different from other batch image processors is its "Task Structure". You can combine Tasks to make processing sequence, that will give you exactly what you want. ImBatch offers many imaging functions (Tasks).

ImBatch features:
-----------------------------------------------------------------------

 o "Task Structure"
  - Combine Tasks to make different processing sequence.

 o Integration into the system.
  - You can add commands to the Windows context menu, by using the ImBatch Context Menu Editor, supplied by ImBatch. That enables you to edit images without leaving Windows Explorer.

 o Scripting System.
  - ImBatch has the Script Editor, that can be used to configure the image processing more flexibly.

 o Processing folders.
  - Image Monitor, that comes with ImBatch, allows you to monitor the images in different directories and automatically apply tasks, when old images are changed or new appeared in it.

 o Tag editor.
  - There is an internal tag editor, in ImBatch, that supports about 70 different EXIF/IPTC tags.
  
 o Intuitive user interface.
  - Use drag and drop Windows ability, to add new images for batch processing.

 o Supporting all popular image formats.
  - ImBatch supports 112 different image formats: 
	TIF,   TIFF, FAX,  G3N,  G3F,   XIF,  GIF, JPG, JPEG, JPE, 
	JIF,   PCX,  BMP,  DIB,  RLE,   ICO,  CUR, PNG, DCM,  DIC, 
	DICOM, WMF,  EMF,  TGA,  TARGA, VDA,  ICB, VST, PXM,  PPM,
	PGM,   PBM,  WBMP, JP2,  J2K,   JPC,  J2C, PS,  EPS,  PDF,
	DCX,   CRW,  CR2,  NEF,  RAW,   PEF,  RAF, X3F, BAY,  ORF,
	SRF,   MRW,  DCR,  SR2,  PSD,   IEV,  LYR, ALL, WDP,  HDP,   
	DNG,   ARW,  KDC,  MEF,  3FR,   K25,  ERF, CAM, CS1,  DC2, 
	DCS,   FFF,  MDC,  MOS,  NRW,   PTX,  PXN, RDC, RW2,  RWL, 
	IIQ,   SRW,  PCD,  CUT,  AVS,   CIN,  DOT, DPX, FITS, FPX, 
	HDF,   MAT,  MIFF, MTV,  PALM,  PICT, PCL, PIX, PWP,  RLA,
	SGI,   SUN,  SVG,  TTF,  VICAR, VIFF, XBM, XCF, JBIG, JBG, 
	BIE,   XPM,  PDF,  DDS
  - Allows working with separate frames of multipage images (GIF, TIFF, DICOM and so on).
 
 o Supports Unicode.
  - Interface can localized into Unicode languages.

 o Live preview.
  - You can see the results of applying tasks for each image before processing.
  
 o Context help.
  - There is a detailed information for each task and its parameters. You can see it simply by pointing the mouse pointer over the icon with a question mark.

 o Skin system.
  - ImBatch supports skins, that helps you completely change the appearance of the program in accordance with your preferences.

 o Command line parameters.
  - You can further automate images processing, using the command line parameters.

  ImBatch.exe [-h [NotSilent]] [-b "SavedTasksFile.bsv"] [-i "ImageFiles" [-ap]] [-r] [-c]
	Parameter                 Description
	-h                        Does not show ImBatch's main window. In this mode, if you don't also set -r parameter, ImBatch will not work and automatically terminate after the start. If there is a NotSilent parameter, then an information window will appear in the end of processing.
	-b "SavedTasksFile.bsv"   Automatically loads tasks from SavedTasksFile.bsv file.
	-i "ImageFiles"           Automatically loads images, specified in ImageFiles part. ImageFiles must be quoted and separated by "|" character.
	-ap                       Force to add all pages in multi-page files (ignore settings).
	-r                        Automatically runs batch image processing.
	-c                        Automatically closes ImBatch on finish.
  
  Also you can write parameters into the text file, where each parameter must be placed on a separate line. Then you must send this file prefixed with @ and enclosed with quotation marks to ImBatch in following form:
  ImBatch.exe "@ParamsFileName"
 
System requirements
-----------------------------------------------------------------------

Minimum system requirements:
 o Intel or AMD x86 CPU with 300 MHz 
 o 128 Mb RAM
 o 5 MB of available hard drive space
 o Operating system Windows 2000 and later

About developers
-----------------------------------------------------------------------
ImBatch, Copyright � 2016, High Motion Software (http://www.HighMotionSoftware.com)


HISTORY
=======================================================================

ImBatch v5.2.0 (13.12.2016)
-----------------------------------------------------------------------
 + Added Gradient Paint task.
 + "Curves" task: added ability to save/load from Adobe Photoshop's curves files (*.acv).
 + Added ability to turn on/off auto-rotating of images based on orientation tag information.
 + Added ability to close Selection window by pressing ESC key.
 * "Save to PDF" task: fixed saving into single file.
 * Fixed writing messages about restrictions in the free version into console window.
 * Fixed problems with accessing to Tags Editor and Script Editor windows after minimizing.

ImBatch v5.1.1 (23.11.2016)
-----------------------------------------------------------------------
 + Tag editor: Added the ability to copy XMP tag names and values to the clipboard.
 + Removed message box sometime appeared on program start.
 * Minor fixes in "Watermark Text" task.
 * "Resize Canvas by Aspect Ratio" task: Added the ability to fill the background with the blurred source image, added background transparency setting.
 * "Resize Canvas" task: Fixed wrong blurred background with some specific options set.
 * "Save as Animated GIF" task: fixed delay time between the frames.

ImBatch v5.1.0 (13.10.2016)
-----------------------------------------------------------------------
 + Added Save In CMYK As task.
 + Added Save To Animated GIF task.
 + 'Save As' task: added configuration options for TIFF and DICOM formats.
 + 'Set Tag' task: added support of image and file attributes for text tags.
 + 'Watermark Text' task: added the ability to wrap text on words.
 + Added ability to set templates for date/time tags.
 + Selecting color from the screen: fixed work with multiple monitors.
 + Selecting color from the screen: added the ability to cancel the color picking.
 * Fixed a rare error that happening while simultaneously updating the preview and loading image for hint.
 * 'AutoCrop' task: fixed work of task in the preview.
 + 'Save As' task: spaces in the name are replaced by underscore.
 * 'Save As' task: fixed error when saving in multi-threaded processing.
 * Image Monitor: fixed error on loading non existent folders on start.

ImBatch v5.0.0 (13.08.2016)
-----------------------------------------------------------------------
 + Added multithreaded processing.
 + Added Selection Tool.
 + Added ability to sort images by all attributes.
 + Added ability to save lossless transformations for JPEG (flips and rotations).
 * Improved tooltip for images (more info plus large thumbnail).
 * 'Watermark Text' task: improved text rendering with Anti-Grain Geometry library.
 * 'Watermark Text' task: simplified access to font parameters.
 * 'Watermark' task: fixed disabled state of task's interface.
 * 'Rotate' task: fixed image sizes update for preview.
 * Fixed script compiling.

ImBatch v4.9.0 (13.06.2016)
-----------------------------------------------------------------------
 + Added Stroke task.
 + Added option to turn on/off beep sound in the end of processing.
 + ImageMonitor: added totally silent mode.
 + Added replacing transparency with white color while saving into the format, that doesn't support transparency.
 + 'Resize Canvas' task: added option to fill new space with blurred image.
 + 'Convert Colors' task: added ability to replace alpha channel with specified color.
 * 'Save As' task: fixed changing 'Common Folder' option after loading tasks list.
 * 'Resize' task: fixed working 'Resize Type' option in Preview panel.
 * Improved algorithm of the Deskew Text task.
 * Fixed saving into DDS format with transparency.
 * Fixed detection of the portable version by the path to the program.
 * Fixed opening 'Save As' task.
 * Fixed image size updating in Preview panel.

ImBatch v4.8.0 (23.03.2016)
-----------------------------------------------------------------------
 + Added support of DDS format.
 + Added Normal Map task.
 * Improved handling of command line parameters.
 * Improved error handling in parameters of bsv-files.


ImBatch v4.7.1 (16.02.2016)
-----------------------------------------------------------------------
 + 'Filter' task: added script support.
 + Added ability to set options for dcraw plugin in Options window.
 * 'Resize' task: fixed DPI changing.

ImBatch v4.7.0 (20.01.2016)
-----------------------------------------------------------------------
 + Added Temperature task.
 + Added Exposure task.
 + Added AutoEqualize Histogram.
 + 'Convert to Gray' task: added controls to adjust red, green and lue channels and brightness.
 + 'Resize' task: added ability to enlarge only or reduce only images.
 * Greatly accelerated change speed of the localization in the program (about 20 times). Also accelerated the launch of the program.

ImBatch v4.6.0 (10.01.2016)
-----------------------------------------------------------------------
 + Added Change channels task.
 + Added input box to enter path in add folder form.
 + 'Filter' task: addded new functions Func_S_FileExists_N, Func_SS_ConcatStr_S, Get_FileNameWithExt_S, Get_FullPath_S.
 + 'Filter' task: adde button to show filtered images.
 * 'Create Contact Sheet' task: corrected work with measurement units.
 * 'Save As' task: now whitespaces are no longer converts to underscores (_).
 * Unchecked images now are rendering with different color.
 * Fixed bug, that happened sometimes, while adding a lot of images.
 * Windows Shell Context menu integration works for folders.

ImBatch v4.5.0 (16.12.2015)
-----------------------------------------------------------------------
 + 'Save to PDF' task: Added tags support in File Name field.
 * Fixed <Day (Short name)> and <Day (Full name)> tags.
 * Image List: changed icons for indicators (EXIF, IPTC, thumbnail), added indicator for XMP. 
 * Image List: added ability to open image in Explorer by clicking on image name caption.
 * 'Save As' task: now image thumbnail in EXIF tags updates correctly.
 * 'Save to PDF' task: added parameters to adjust JPEG compression and ability to convert to grayscale.
 * 'Save to PDF' task: to correctly compress 24 bpp images with RLE, G4FAX or G4FAX2D compressions, its automatically converts to black-and-white images.
 * 'Save to PDF' task: added AutoFit option in Paper Format parameter (the size of each page adjusts to image size).
 * 'Convert Colors' task: improved algorithm for converting to black-and-white image.

ImBatch v4.4.0 (24.11.2015)
-----------------------------------------------------------------------
 + Added support of multipage image files.
 + Added support of PDF.
 + Added new command line option (-ap) for multipage files.
 * 'Save To PDF' task: Fixed task working with 'Separate PDF file for every image' option on.
 * 'Create Contact Sheet' task: Now the type of stored contact sheet files depends on the extension of 'File Name' option.
 * Improved Options dialog box.
 * Added translation for some controls in Add folders recursively confirmation dialog box.
 * Some improvements in 'Save to PDF' task interface.

ImBatch v4.3.1 (02.11.2015)
-----------------------------------------------------------------------
 + 'Watermark' task: Added ability to drag watermark with a mouse on Preview panel.
 * 'Upload to FTP': If file exists, it will be rewritten.
 * Fixed a bug with passing images to the program as command line parameter.
 * Fixed incorrect values in the preview panel, if the task list has 'Resize Canvas' task.

ImBatch v4.3.0 (03.10.2015)
-----------------------------------------------------------------------
 + 'Upload To FTP' task: Added ability to change an extension of uploading images.
 * Rewritten image loading function. Now images are loading in a separate thread.
 * Fixed presets loading from the script for 'Curves' task.
 * Fixed memory leak while loading images.
 * Fixed some small bugs.

ImBatch v4.2.0 (07.09.2015)
-----------------------------------------------------------------------
 + Added new tool: Script Editor.
 + Added ability to show processing progress on Windows TaskBar (on Windows 7 and above).
 * Fixed some small bugs.

ImBatch v4.1.1 (19.08.2015)
-----------------------------------------------------------------------
 + Added the ability to install a portable version.
 * Updated French translation.
 * 'Set EXIF/IPTC Tags' task: fixed bug in setting tag EXIF version.
 * Improved handling of invalid input values.
 * Fixed wrong undo changes for some parameters.
 * Fixed the ability to turn off and on the integration in the Windows Context Menu.

ImBatch v4.1.0 (12.08.2015)
-----------------------------------------------------------------------
 + Added Create Contact Sheet task.
 + Added ability to set selection dimensions ('Add selection' task) with mouse in Preview panel.
 + Added Polish translation.
 * Updated Chinese translation.
 * Small fixes in Russian translation.
 * Fixed freezes when you drag the Preview window.
 * Fixed image sorting.
 * Fixed periodical crashes while selecting images in the list.
 * Some minor fixes according to user reports.

ImBatch v4.0.1 (20.07.2015)
-----------------------------------------------------------------------
 + 'Deskew Text' task: added ability to set antialiasing.
 + 'Deskew Text' task: added ability to set background color.
 * Fixed some bugs in filtering images list.

ImBatch v4.0.0 (16.07.2015)
-----------------------------------------------------------------------
 + Added Add Selection task.
 + Added Make Selection Feather task.
 + Added Make Selection Gradient task.
 + Added Invert Selection task.
 + Added Deselect task.
 + Added Fill Color task.
 + Added list of 10 previously opened tasks files for Open Tasks button.
 + Added list of 10 previously saved tasks files for Save Tasks button.
 + Added quick search tool to search images.
 + 'Remove EXIF/IPTC Tags' task: added ability to remove XMP tags only.
 * 'Remove EXIF/IPTC Tags' task: fixed XMP tags removing while removing all tags (for JPEG images).
 * Fixed some bugs.
 * Some UI and performance improvements.

ImBatch v3.9.0 (26.05.2015)
-----------------------------------------------------------------------
 + Added Anaglyph task.
 + Added Fish Eye task.
 + Added Premium support for users who purchased a license.
 * Fixed ImageMonitor autostart function on Windows startup.
 * Improved determination of image types.
 * Fixed some memory leaks.
 * Some minor fixes according to user reports.

ImBatch v3.8.1 (09.04.2015)
-----------------------------------------------------------------------
 + Added commands for image selecting.
 + Added shortcuts for image list commands.
 * Fixed working of mouse wheel in the image list.
 * Fixed working of Add tag button in Optimize for Web task.
 * Fixed other issues according to user reports.

ImBatch v3.8.0 (30.03.2015)
-----------------------------------------------------------------------
 + Added Resize Canvas by Aspect Ratio task.
 + Added Optimize for Web task.
 * Enhanced color setting controls.
 * Updated French and Italian languages.
 * Fixed some small bugs. 

ImBatch v3.7.0 (06.03.2015)
-----------------------------------------------------------------------
 + 'Watermark Text' task: Added ability to set direction for offset.
 + 'Watermark' task: Added ability to set direction for offset.
 + Added mask support in command line.
 + Added ability to sort images list.
 + Added ability to send message to developers from program interface.
 + Added ability to use any XMP tags in tasks.
 + Added statistic showing at the end of image processing.
 * 'Watermark Text' task: improved interface for justification paramters.
 * 'Watermark' task: improved interface for justification parameters.
 * 'Watermark Text' task: Fixed displaying text with breakings in editor control.
 * 'Set EXIF/IPTC tags' task: fixed working of textual tags.
 * Fixed errors, that may happens some time in 'Watermark Text' � 'Photo Collage' tasks.
 * Fixed saving images on UNC network path.
 * Improved calculating of remaining time in processing dialog.
 * Added ability to store the path in the add folder with images dialog.

ImBatch v3.6.0 (08.02.2015)
-----------------------------------------------------------------------
 + EXIF/IPTC Editor: Added 35 new EXIF GPS tags and IPTC tag Sublocation
 + EXIF/IPTC Editor: Added the ability to toggle visibility for the tags.
 + Added support for new tags in 'Set EXIF/IPTC Tag', 'Remove EXIF/IPTC Tags', 'Save As', 'Copy', 'Rename/Move' and 'Watermark Text' tasks.
 + Added support for XMP tags in tags editor (read only).
 + Thanks to our users:
   - Added Swedish interface and help translation.
   - Added Italian help and updated interface translation. 
   - Updated French interface and help translation.
 + 'Round Corners' task: added checkbox for transparent corners.
 * Fixed interface for big system fonts.
 * Fixed issue in Preview window.
 * Fixed some UI issues.

ImBatch v3.5.0 (12.01.2015)
-----------------------------------------------------------------------
 + Added Deskew Text task.
 * Big changes in Context menu integration functionality:
  * Fixed crashing on non-image files.
  * Enhanced support of unicode filenames.
  * Some performance improvements.
  * Added support of unlimited files count.
 * 'Watermark' task: Fixed working of 'Height' parameter.

ImBatch v3.4.0 (23.12.2014)
-----------------------------------------------------------------------
 + Added French interface and help translation.
 + Enhanced saving function: added ability to preserve folder structure in Save As, Copy and Rename/Move tasks.
 * Fixed converting to JPEG format unmodified image.
 * Minor bug fixes.
 
ImBatch v3.3.0 (04.12.2014)
-----------------------------------------------------------------------
 + Added Reset filter task, so you can use different filters in one go.
 + Added the ability to preserve folder structure in Upload to FTP task.
 * Fixed some bugs according to your bug reports.

ImBatch v3.2.2 (04.11.2014)
-----------------------------------------------------------------------
 * Fixed some weird painting issues after the window resize.
 + Added displaying the image resolution in the preview pane.

ImBatch v3.2.1 (31.10.2014)
-----------------------------------------------------------------------
 * Fixed handling Date tags in EXIF metadata.
 * Chinese translation updated.
 * RAW formats support library updated.

ImBatch v3.2.0 (26.10.2014)
-----------------------------------------------------------------------
 + Added Copy and Delete tasks.
 + Rename tasks has named Rename/Move task.
 + Added new tasks category: File.
 + Added 5 new skins: AutumnSky, Emerald, FM, MetroUI, Ubuntu.
 + 'Rename/Move' task: addded reset buttons for New File Name and New File Path parameters.
 * Image Monitor: fixed working of Duplicate button.
 * Image Monitor: some fixing and improvements in UI.
 * Many minor bug fixes.

ImBatch v3.1.0 (08.09.2014)
-----------------------------------------------------------------------
 + Added task Upload To FTP.
 + 'Watermark Text' task: Added Add Shadow parameter.
 * Fixed some problems with unicode symbols.
 * Optimized loading tasks form file.
 * Fixed some minor bugs.

ImBatch v3.0.0 (04.08.2014)
-----------------------------------------------------------------------
 + Added task Curves.
 + Added task Filter.
 * Image Monitor tool was rewritten from the scratch.
 * Many minor bug fixes.

ImBatch v2.7.0 (27.06.2014)
-----------------------------------------------------------------------
 + Added task Mosaic.
 * 'Watermark Text' task: Added Width and Height parameters to bound text.
 * 'Watermark Text' task: Changed the text field: you can now specify a multiline text.
 * 'Resize' task: Fixed task work in the preview window.
 * Improved program error handling.
 * Many minor bug fixes.

ImBatch v2.6.0 (20.05.2014)
-----------------------------------------------------------------------
 + Added task Extract Channel.
 + Added task Photo Collage.
 * 'Watermark Text' task: Fixed text rotation.
 * 'Round Corners' task: Fixed error when setting huge values.
 * Message shown when program can't save images.
 * Now thumbnails are loading only on demand.
 * Reduced memory usage for thumbnails.
 * Added meta information indicators in images list.
 * Now images list is showing status information.
 * ImBatch Context Menu: fixed crash that occurred on some files.
 * Many other small fixes.

ImBatch v2.5.0 (30.03.2014)
-----------------------------------------------------------------------
 + Added task Replace Colors.
 + Added the ability to reset all task's controls to its default values.
 * Restored work of transparency in images in the preview window.
 * Hints for tasks don't disappear.
 * 'Resize' task: fixed task work in Preview window.
 * 'Save To PDF' task: added the ability to create individual PDF file for each image.
 * 'Save As' task: fixed incorrect work of the default settings switcher.
 * Changed work of 'Current Index' tag. Now you can set the initial value of the index (for example: <#### 5>).
 * Fixed errors in 'Save to PDF' task.
 * Some other minor fixes.

ImBatch v2.4.0 (12.03.2014)
-----------------------------------------------------------------------
 * Now ImBatch has FULL Unicode support!
 * Completely redesigned process of editing tasks.
 * Now Preview updates while editing tasks.
 * 'Save As' task: now extensions are in lower case.
 * Added Hungarian interface translation
 * Added Chinese interface translation

ImBatch v2.3.0 (01.02.2014)
-----------------------------------------------------------------------
 + Added task Invert.
 * Significantly accelerated loading of images.
 * Significantly accelerated processing of Frame task.
 * Significantly accelerated processing of images in Preview window in Fit mode.
 * Now sizes of main window and panels are automatically saved and restored.
 * Panels resized proportionally to main window size.
 * Some changes in EXIF/IPTC Editor GUI.
 * Some changes in Image Monitor GUI.
 * Many small fixes according to user bug reports.

ImBatch v2.2.0 (09.01.2014)
-----------------------------------------------------------------------
 + Added new tool - EXIF/IPTC Editor.
 + Added support of 40 new EXIF tags.
 + Added ability to see original image in preview window.
 * Enhanced functionallity of preview window.
 * Enhanced informativity of processing window.
 * Many small changes in GUI.
 * Many small fixes according to user bug reports.

ImBatch v2.1.0 (09.12.2013)
-----------------------------------------------------------------------
 + Added tasks context help in English, Russian and Ukrainian.
 + Added task AutoEnhance 3.
 * Some improvements in ContextMenuEditor GUI.
 * Improved GUI of ImageMonitor and fixed some errors.
 * Fixed error on adding AutoCrop task.
 * Added ability to set relative path in Save As task.
 * Fixed error on empty File Name parameter in Frame task.
 * Fixed some other small bugs.

ImBatch v2.0.0 (11.11.2013)
-----------------------------------------------------------------------
 + Added ImageMonitor.
 + Added ContextMenuEditor.
 + Added saving/loading of last session.
 + Added ability to load saved tasks (BSV file) with drag'n'drop operation.
 + Added task AutoEnhance 1.
 + Added task AutoEnhance 2.
 * Now tasks are separated by categories.
 * Changed dialog to add new task.

 - Now you can support development of ImBatch .

ImBatch v1.9.0 (29.09.2013)
-----------------------------------------------------------------------
 + Added task Sharpen
 + Added task Sepia
 + 'Rotate' task: Added 'Use EXIF Info' parameter: Now you can automatically rotate images by using their internal info.
 + 'AutoCrop' task: Added 'Crop Type' and 'Alpha' parameters for automatic image cropping by transparency.
 * Some bug fixing.
 * Some localization fixing.

ImBatch v1.8.0 (15.08.2013)
-----------------------------------------------------------------------
 + Added task Color Balance
 + Added task Brightness/Contrast
 + Added task White Balance
 + Added task Rename
 + 'Publish on Facebook' task: Added 'Page' parameter: Now you can upload images to your Facebook pages.
 + Added Italian language
 * Now if there are no 'Save As' or 'Add To PDF' or 'Publish On Facebook' tasks, ImBatch will automatically save images and override files.

ImBatch v1.7.0 (29.06.2013)
-----------------------------------------------------------------------
 + Added task Watermark Text.
 + Added task Frame.
 + Added task AutoCrop.
 + Added an option to automatically expand tasks after insertion new task.
 * 'Set EXIF/IPTC Tag' task: EXIF/IPTC string tags are localized now.
 * 'Watermark' task: fixed some interface problems.
 * 'Crop' task is now renamed to 'Resize Canvas' task.
 * Fixed undo/redo tool.

ImBatch v1.6.0 (11.06.2013)
-----------------------------------------------------------------------
 + Added task Reset To Origin
 + '3D Image' task: Added 'Background Color' parameter.
 + 'Round Corners' task: Added 'Background Color' parameter.
 + 'Soft Shadow' task: Added 'Background Color' parameter.
 + Added translation for colors.
 * Improved tasks drawing while dragging.
 * Fixed: task's editing after dragging.

ImBatch v1.5.0 (02.05.2013)
-----------------------------------------------------------------------
 + Added task 3D Image
 + Added task Motion Blur
 + Added button to add folders with images
 + Added a blinking for run batch image processing button when all is ready for it.
 * Unchecked images are now drawn in gray, to better distinguish them.
 * 'Add to PDF' task: if 'File name' parameter contains a file name without the 'PDF' extension, then it is automatically added.
 * Fixed minor bugs, removed obsolete code.
 * Some localization fixes.

ImBatch v1.4.0 (25.03.2013)
-----------------------------------------------------------------------
 + Added new task - "Post to Facebook"
 * Fixed bugs according to users reports.

ImBatch v1.3.0 (22.02.2013)
-----------------------------------------------------------------------
 * Now all task's values are loaded from the last session.
 * All plugins are loaded by default.
 * All data files are stored in Windows common application data folder.
 * Now you can collapse/expand task by double-clicking.

ImBatch v1.2.0 (31.12.2012)
-----------------------------------------------------------------------
 + Added ability to change program skin. Added skins: Afterburner, Android OS, MacOS2, Windows 8, Winter2003.
 + Added Gaussian Blur task.
 + Added Inner Shadow task.
 + Added default menu item 'Send to ImBatch' for Windows shell context menu extension.
 * Small errors fixing and improvements in Windows shell context menu extensions.
 * Fixed working of -c parameter (auto closing after processing)
 * 'Set Tag' task: fixed small errors in date/time tags.
 * 'Convert Colors' task: small errors fixing.

ImBatch v1.1.4 (24.12.2012)
-----------------------------------------------------------------------
 + 'Crop' task: Added ability to save/load values of 'Left', 'Right', 'Top', 'Bottom' parameters.
 * Changes in preview window interface: added checkbox to enable automatic refresh.
 * Fully rewrited Windows shell context menu extension.
 + Added 64-bit version of Windows shell context menu extension.

ImBatch v1.1.0 (01.12.2012)
-----------------------------------------------------------------------
 + Added a plugin system to expand the number of supported image formats.
   + Added DCRaw plugin, that allows you to decode raw format images from digital cameras.
   + Added ImageMagick plugin, that adds supports for more than 90 image formats, including PCD, DICOM, CUT, AVS, CIN, DOT, DPX, FITS, FPX, HDF, MAT, MIFF, MTV, PALM, PCL, PICT, PIX, PWP, RLA, SGI, SUN, SVG, TTF, VIFF, XBM, XCF, XPM.
   + Added JBIG plugin, that adds support for JBIG, JBG, JBIE formats.
 + Added Crop task.
 + Added Color Adjustment task.
 + Added ability to associate ImBatch with Saved Tasks (*.BSV) files.
 * Some changes in Windows integration code.
 * Fixed Watermark task applying.


ImBatch v1.0.0 (01.12.2012)
-----------------------------------------------------------------------
 + Added Quick Start Guide
 + Added option for choosing main window borders' painting (native or skin).
 + 'Watermark' task: Added 'Constrain Proportions' parameter.
 + 'Watermark' task: Added button for choosing file for 'File Name' parameter.
 + 'Watermark' task: Added ability to save/load values of 'Width', 'Height', 'Vertical Offset' and 'Horizontal Offset' parameters.
 * 'Watermark' task: Fixed saving/loading values of 'File Name' parameter.
 * 'Watermark' task: Changed sizes of editing controls for 'Height', 'Vertical Offset' and 'Horizontal Offset' parameters.
 * 'Watermark' task: Fixed editing of 'Horizontal Justification' and 'Vertical Justification' parameters.
 * 'Add To PDF' task: Changed controls for 'File Name', 'Author', 'Creator', 'Keywords', 'Subject', 'Title', 'Producer'. Added ability to save and load values for this parameters.

ImBatch v1.0.0 RC1 (19.09.2012)
-----------------------------------------------------------------------
 + Added Add To PDF task.
 + Added Watermark task.
 + Added undo/redo actions for tasks.
 + Added ability to edit task properties in one click.
 + Added command line parameters.
 + Added Microsoft Windows integration (now you can run any task from Windows context menu).
 * Fixed bug with task panel resizing.
 * 'Shift Time' task: fixed task saving.

ImBatch v0.9.0 (17.02.2012)
-----------------------------------------------------------------------
 + Added Set Tag task.
 + Added Remove Tags task.
 + Added Shift Time task.
 + 'Save As' task: Added a lot of new template parameters for 'File Name' parameter.
 + 'Save As' task: Added new template parameters for 'Folder' parameter.
 * 'Save As' task: Now if current image has not changed it just copies image.
 * Fixed Update Checking system.
 * Fixed Preview Panel buttons states.
 * Many minor bug fixes.

ImBatch v0.8.5 (10.01.2012)
-----------------------------------------------------------------------
 + Added Preview pane.
 + Added Convert To Gray task.
 + Added Mexican Spanish localization.
 * Fixed BPP calculating for image list view.
 * Fixed bug with dialogs position.
 * Fixed bug with deleting task.
 * 'Save As' task: fixed bug with overriding images.
 * 'Round Image' task: added ability for saving and loading options.

ImBatch v0.8.0 (04.01.2012)
-----------------------------------------------------------------------
 + Added Convert Colors task.
 + Added drag&drop support for folders.
 * Added functionality for SPACE button: check/uncheck tasks or toggle visibility of tasks parameters.
 * 'Save As' task: Changed default value for 'File Name' parameter.
 * 'Save As' task: All values for 'File Name' parameter are stored into the list.
 * 'Save As' task: All values for 'Folder' parameter are stored into the list.
 * 'Resize' task: Fixed bug with resizing.
 * 'Resize' task: When 'Width' and 'Height' parameters are set to 'Proportional' task will resize to DPI value.
 * 'Soft Shadow' task: All values for 'X Offset' and 'Y Offset' parameters are stored into the list.
 * 'Soft Shadow' task: 'X Offset' and 'Y Offset' parameters can be set in pixels, percents, mm, cm or inches.
 * 'Round Image' task: All values for 'Round Width' and 'Round Height' parameters are stored into the list.
 * 'Round Image' task: 'Round Width' and 'Round Height' parameters can be set in pixels, percents, mm, cm or inches.

ImBatch v0.7.5 (27.12.2011)
-----------------------------------------------------------------------
 + Added Soft Shadow task.
 + Added Flip task.
 + Added Round Corners task.
 * Fixed edit panel position in edit mode.
 * Fixed bug with task deleting in edit mode.
 * Changed control for color editing.
 * Updated localization.

ImBatch v0.7.0 (18.12.2011)
-----------------------------------------------------------------------
 + Added ability to exclude individual tasks.
 + Added ability to hide some task parameters.
 + Added Rotate task.
 + Added update checking system.
 + Added width, height and BPP information for images.
 * Fixed image list hints.
 * Fixed tasks saving function.

ImBatch v0.6.0 (11.12.2011)
-----------------------------------------------------------------------
 + Created new control with thumbnails for image list.
 + Added hints for image list.
 * Updated localization.

ImBatch v0.5.4 (02.12.2011)
-----------------------------------------------------------------------
 + Added commands for image files positioning.
 + Added buttons for task positioning.
 + Added command to interrupt processing.
 + Added shortcuts for almost every command.
 * Fixed edit mode elements (positioning and stretching of controls).
 * Enhanced user graphical interface.
 * Improved keyboard control.

ImBatch v0.5.1 (26.11.2011)
-----------------------------------------------------------------------
 + Added 'If file exists' condition for 'Save As' task.
 * Fixed changing language code.
 * Fixed ability for adding of multiple image files for processing via open dialog box.
 * Fixed 'Add Task' dialog box position.
 * Fixed 'Resize' task code.
 * Updated localization.

ImBatch v0.5.0 (24.11.2011)
-----------------------------------------------------------------------
 o First public release.
